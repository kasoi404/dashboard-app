
fetch('/api/stats')
  .then(response => response.json())
  .then(data => {
    const statsDiv = document.getElementById('stats');
    statsDiv.innerHTML = `
      <p>Total Sales: ${data.totalSales}</p>
      <p>Visitors: ${data.visitors}</p>
      <p>Orders: ${data.orders}</p>
      <p>Refunded: ${data.refunded}</p>
    `;
  });
