
const express = require('express');
const cors = require('cors');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.static('public'));
app.use(express.json());

// Example API endpoint
app.get('/api/stats', (req, res) => {
  res.json({
    totalSales: 890,
    visitors: 1234,
    orders: 567,
    refunded: 123
  });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
